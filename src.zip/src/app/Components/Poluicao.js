'use client'
import { useState, useEffect } from 'react';
import styles from "./poluicao.module.css";

const Poluicao = () => {
  const [aqiData, setAqiData] = useState(null);

  const fetchAQIData = async () => {
    try {
      const response = await fetch('https://api.waqi.info/feed/guarulhos/?token=7e6a7ed24e1e4fcadb7b32f9eb48c8faad9873cf');
      const data = await response.json();
      
      setAqiData(data.data);
    } catch (error) {
      console.error('Erro ao buscar dados do AQI:', error);
    }
  };

  useEffect(() => {
    fetchAQIData();
  }, []);

  return (
    <div className={styles.divAPI}>
      {aqiData ? (
        <div className={styles.divAQI}>
          <h2>Dados de Qualidade do Ar para {aqiData.city.name}</h2>
          <p>Índice de Qualidade do Ar (AQI): {aqiData.aqi}</p>
          <p>Temperatura: {aqiData.iaqi.t.v} °C</p>
          <p>Umidade: {aqiData.iaqi.h.v}%</p>
          <p>Pressão Atmosférica: {aqiData.iaqi.p.v} hPa</p>
          <p>Velocidade do Vento: {aqiData.iaqi.w.v} m/s</p>
        </div>
      ) : (
        <p>Carregando dados de AQI...</p>
      )}
    </div>
  );
};

export default Poluicao;
