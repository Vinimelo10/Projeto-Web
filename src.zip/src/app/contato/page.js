import Menu from "../Components/Menu";

export default function Contato() {
    return (
        <>
        <header>
        <img src="../Imagens/logo.png" className='logo'/>
        <Menu />
        </header>
        </>
    );
}