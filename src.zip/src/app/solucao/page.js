import Cabecalho from "../Components/Menu";
import Footer from "../Components/Footer";
import Menu from "../Components/Menu";
import Poluicao from "../Components/Poluicao";
import styles from "./page.module.css";

export default function Solucao() {
    return (
        <>
        <header>
        <img src="../Imagens/logo.png" className='logo'/>
        <Menu />
        </header>
            <form>
                <input type="text" placeholder="Pesquise a cidade desejada" className={styles.pesquisa}></input>
            </form>
            <Poluicao />
        <br/><br/><br/>
        <div className="divApi">
            <p>Espaço Reservado para API</p>
        </div>
        <br/><br/><br/>
        <Footer />
        </>
    );
}